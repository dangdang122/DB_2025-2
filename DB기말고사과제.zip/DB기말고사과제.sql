-- 1. 회원 테이블 (MEMBER)
CREATE TABLE MEMBER (
    member_id VARCHAR(20) PRIMARY KEY,
    password VARCHAR(50) NOT NULL,
    name VARCHAR(20) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    phone VARCHAR(30) NOT NULL,
    address VARCHAR(50) NOT NULL
);

-- 2. 도서 테이블 (BOOK)
CREATE TABLE BOOK (
    book_id INT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    author VARCHAR(50) NOT NULL,
    publisher VARCHAR(30) NOT NULL,
    category VARCHAR(30) NOT NULL,
    price INT NOT NULL,
    stock INT NOT NULL,
    CHECK (stock >= 0)
);

-- 3. 장바구니 테이블 (CART)
CREATE TABLE CART (
    cart_id INT PRIMARY KEY,
    member_id VARCHAR(20) NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (member_id) REFERENCES MEMBER(member_id),
    FOREIGN KEY (book_id) REFERENCES BOOK(book_id)
);

-- 4. 주문 테이블 (Orders)
CREATE TABLE Orders (
    order_id VARCHAR(20) PRIMARY KEY,
    member_id VARCHAR(20) NOT NULL,
    order_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL,
    order_amount INT NOT NULL,
    FOREIGN KEY (member_id) REFERENCES MEMBER(member_id)
);

-- 5. 주문 상세 테이블 (Orders_Detail)
CREATE TABLE Orders_Detail (
    order_id VARCHAR(20) NOT NULL,
    book_id INT NOT NULL,
    price INT NOT NULL,
    quantity INT NOT NULL,
    PRIMARY KEY (order_id, book_id),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (book_id) REFERENCES BOOK(book_id)
);

-- 6. 결제 테이블 (Payment)
CREATE TABLE Payment (
    payment_id INT PRIMARY KEY,
    order_id VARCHAR(20) UNIQUE NOT NULL,
    method VARCHAR(20) NOT NULL,
    pay_date DATE NOT NULL,
    payment_amount INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);

-- 7. 리뷰 테이블 (Review)
CREATE TABLE Review (
    review_id INT PRIMARY KEY,
    member_id VARCHAR(20) NOT NULL,
    book_id INT NOT NULL,
    content CLOB NOT NULL,
    rating INT NOT NULL,
    created_at DATE NOT NULL,
    FOREIGN KEY (member_id) REFERENCES MEMBER(member_id),
    FOREIGN KEY (book_id) REFERENCES BOOK(book_id)
);